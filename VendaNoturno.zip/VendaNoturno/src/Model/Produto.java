/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Bruno
 */
public class Produto {
    private String nome;
    private float valor;
    private int codbarra;
    public Produto(){}

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the valor
     */
    public float getValor() {
        return valor;
    }

    /**
     * @param valor the valor to set
     */
    public void setValor(float valor) {
        this.valor = valor;
    }

    /**
     * @return the codbarra
     */
    public int getCodbarra() {
        return codbarra;
    }

    /**
     * @param codbarra the codbarra to set
     */
    public void setCodbarra(int codbarra) {
        this.codbarra = codbarra;
    }
    
}//fim produto
