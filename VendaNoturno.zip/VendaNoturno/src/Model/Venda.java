/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Bruno
 */
public class Venda {
    private float valortotal;
    private float valortroco;
    private float valorpago;
    public Venda(){}

    /**
     * @return the valortotal
     */
    public float getValortotal() {
        return valortotal;
    }

    /**
     * @param valortotal the valortotal to set
     */
    public void setValortotal(float valortotal) {
        this.valortotal = valortotal;
    }

    /**
     * @return the valortroco
     */
    public float getValortroco() {
        return valortroco;
    }

    /**
     * @param valortroco the valortroco to set
     */
    public void setValortroco(float valortroco) {
        this.valortroco = valortroco;
    }

    /**
     * @return the valorpago
     */
    public float getValorpago() {
        return valorpago;
    }

    /**
     * @param valorpago the valorpago to set
     */
    public void setValorpago(float valorpago) {
        this.valorpago = valorpago;
    }
    
}//fim venda
