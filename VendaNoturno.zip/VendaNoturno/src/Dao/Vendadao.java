/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import Model.Venda;
import java.util.ArrayList;

/**
 *
 * @author Bruno
 */
public class Vendadao {
protected ArrayList<Venda> lista=new ArrayList();    
 
public float Calcularvalortotal(int qntd,float vu){
float vt;
Venda v =new Venda();
vt=qntd*vu;
v.setValortotal(vt);
lista.add(v);
return vt;
}

public float Calculartroco(float vt,float vp){
float valortroco;
valortroco=vp-vt;
return valortroco;
}
public float Fecharcaixa(){
float total=0;
    for(Venda aux:lista){
    total=total+aux.getValortotal();
    }
    return total;
}

}//fim venda
