
package Dao;

import Model.Produto;
import java.util.ArrayList;


public class Produtodao {
protected ArrayList<Produto> lista=new ArrayList();
  
public void Cadastrarproduto(Produto p){
lista.add(p);
}
public Produto Pesquisar(String nome){
for(Produto aux:lista){
 if(aux.getNome().equals(nome)){
 return aux;
 }//fimif
}//fimfor
return null;    
}//fim pesquisar

}//fim produto
