/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import Model.Usuario;

/**
 *
 * @author Bruno
 */
public class Usuariodao {

public boolean Realizarlogin(Usuario user){
if(user.getLogin().equals("adm") && user.getSenha()==123){
return true;
}//fim 
return false;
}//fim realizar login    
    
    
}//fim usuariodao
