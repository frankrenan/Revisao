/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;
import java.util.ArrayList;
import Model.*;
/**
 *
 * @author Bruno
 */
public class Funcionariodao extends Usuariodao{
protected ArrayList<Funcionario> lista = new ArrayList();   
    
public void Cadastrarfuncionario(Funcionario f){
lista.add(f);
}//fimcadastrar

@Override
public boolean Realizarlogin(Usuario user){
 for(Funcionario aux:lista){
   if(aux.getLogin().equals(user.getLogin())&& aux.getSenha()==user.getSenha()){
   return true;
   }//fim if
 }//fim for
    return false;
}//realizar login


}//fim classe funcionariodao
